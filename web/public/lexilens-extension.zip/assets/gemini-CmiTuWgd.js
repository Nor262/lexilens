const k="gemini-3.0-flash";function _(a){let n=a.trim();return n.startsWith("```json")?n=n.replace(/^```json\s*/i,"").replace(/\s*```$/,""):n.startsWith("```")&&(n=n.replace(/^```\s*/,"").replace(/\s*```$/,"")),n.trim()}async function L(a){const n=["v1beta","v1"],c=[];for(const e of n)try{const o=await fetch(`https://generativelanguage.googleapis.com/${e}/models?key=${a}`);if(!o.ok)continue;const h=await o.json();if(Array.isArray(h==null?void 0:h.models)){for(const r of h.models)if((r.supportedGenerationMethods||[]).includes("generateContent")){const d=(r.name||"").replace(/^models\//,"");c.some(f=>f.name===d)||c.push({name:d,displayName:r.displayName||d,apiVersion:e})}}}catch(o){console.warn(`[LexiLens] Failed querying ${e}/models:`,o)}return c}async function v(a,n,c){var d,f,y,b,w,$,V,x,N,A,C;const e=[],o=n&&n!=="gemini-2.0-flash"&&n!=="gemini-2.5-flash"?n:k;e.push({name:o,apiVersion:"v1beta"}),e.push({name:o,apiVersion:"v1"});const h=["gemini-3.0-flash","gemini-3-flash-preview","gemini-1.5-flash","gemini-1.5-flash-latest","gemini-2.5-flash","gemini-1.5-pro"];for(const i of h)e.some(s=>s.name===i&&s.apiVersion==="v1beta")||e.push({name:i,apiVersion:"v1beta"}),e.some(s=>s.name===i&&s.apiVersion==="v1")||e.push({name:i,apiVersion:"v1"});const r=async(i,s)=>{const t=`https://generativelanguage.googleapis.com/${s}/models/${i}:generateContent?key=${a}`;return fetch(t,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:c,generationConfig:{temperature:.2,responseMimeType:"application/json"}})})};let p="";const u=new Set;for(const i of e){const s=`${i.apiVersion}/${i.name}`;if(!u.has(s)){u.add(s);try{const t=await r(i.name,i.apiVersion);if(t.ok){const m=await t.json(),g=(w=(b=(y=(f=(d=m==null?void 0:m.candidates)==null?void 0:d[0])==null?void 0:f.content)==null?void 0:y.parts)==null?void 0:b[0])==null?void 0:w.text;if(g)return _(g)}else if(p=await t.text(),t.status===400&&p.includes("API_KEY_INVALID"))throw new Error("API Key Gemini không hợp lệ. Vui lòng kiểm tra lại trong phần Cài đặt.")}catch(t){if(($=t.message)!=null&&$.includes("API Key Gemini không hợp lệ"))throw t}}}try{console.info("[LexiLens] Discovering available models via ModelService.ListModels...");const s=[...await L(a)].sort((t,m)=>{const g=l=>/gemini-3[.-]0-flash/i.test(l)?100:/gemini-3/i.test(l)?90:/gemini-1\.5-flash/i.test(l)?80:/gemini-2\.5-flash/i.test(l)?70:/flash/i.test(l)?60:10;return g(m.name)-g(t.name)});for(const t of s){const m=`${t.apiVersion}/${t.name}`;if(!u.has(m)){u.add(m);try{console.info(`[LexiLens] Trying discovered model: ${t.name} (${t.apiVersion})`);const g=await r(t.name,t.apiVersion);if(g.ok){const l=await g.json(),S=(C=(A=(N=(x=(V=l==null?void 0:l.candidates)==null?void 0:V[0])==null?void 0:x.content)==null?void 0:N.parts)==null?void 0:A[0])==null?void 0:C.text;if(S)return _(S)}else p=await g.text()}catch{}}}}catch(i){console.warn("[LexiLens] Dynamic model discovery failed:",i)}throw new Error(`Gemini API Error: Không thể gọi model khả dụng. Chi tiết: ${p}`)}async function T(a,n,c,e,o,h,r){const p=`
Bạn là trợ lý từ vựng học thuật cho sinh viên Việt Nam học chuyên ngành Ngôn ngữ Anh.
Lĩnh vực/Chủ đề: ${h||"auto"} ("auto" = tự đoán từ tiêu đề trang và câu văn).
Tiêu đề trang: ${o||"Bài báo"}
Câu chứa từ: "${e}"
Từ/cụm từ cần giải thích: "${c}"
${r?`Phiên âm IPA chuẩn từ điển: ${r}`:""}

Quy tắc bắt buộc:
1. "meaning_vi": Nghĩa tiếng Việt CHÍNH XÁC trong ngữ cảnh câu này (ưu tiên thuật ngữ chuyên ngành nếu có).
2. "why": Một câu tiếng Việt ngắn gọn chỉ ra manh mối ngữ cảnh (từ nào, cấu trúc nào xung quanh) quyết định nghĩa này.
3. "definition_en": Định nghĩa súc tích bằng tiếng Anh (simple English).
4. "other_meanings": Mảng tối đa 2-3 nghĩa phổ thông khác thường gặp.
5. "collocations": 2-3 cụm kết hợp từ phổ biến.
6. Chỉ trả về JSON tuân thủ đúng cấu trúc. Không thêm văn bản phụ.

JSON format:
{
  "headword": "từ gốc (lemma)",
  "pos": "verb | noun | adjective | adverb | idiom | phrase",
  "ipa": "${r||"/phiên âm/"}",
  "meaning_vi": "nghĩa trong ngữ cảnh",
  "definition_en": "english definition",
  "why": "Lý do vì sao nghĩa này...",
  "other_meanings": ["nghĩa 1", "nghĩa 2"],
  "collocations": ["collocation 1", "collocation 2"],
  "detected_topic": "lĩnh vực phát hiện được"
}
`,u=await v(a,n,[{parts:[{text:p}]}]);return{...JSON.parse(u),source:r?"dictionary+gemini":"gemini_fallback"}}async function j(a,n,c){const e=`
Phân tích ngữ pháp và cấu trúc câu tiếng Anh sau cho sinh viên chuyên ngành Ngôn ngữ Anh:
Câu: "${c}"

Yêu cầu học thuật:
1. Dịch câu sang tiếng Việt tự nhiên, chuẩn văn phong học thuật.
2. Tách câu thành các mệnh đề ("clauses"):
   - type: "main" (mệnh đề chính), "subordinate" (mệnh đề phụ trạng ngữ/danh từ), "relative" (mệnh đề quan hệ), "participial" (cụm phân từ/rút gọn).
   - text: đoạn văn bản gốc tương ứng.
   - role: vai trò ngữ pháp (ví dụ: "chủ ngữ chính và vị ngữ", "bổ nghĩa thời gian", "bổ ngữ cho danh từ X").
3. "simplified": Viết lại câu bằng cấu trúc đơn giản, dễ hiểu hơn.
4. "grammar_points": Tối đa 3 điểm ngữ pháp đáng chú ý (ví dụ: "Đảo ngữ", "Câu bị động kép", "Rút gọn mệnh đề quan hệ").

Chỉ trả về JSON thuần theo format:
{
  "translation_vi": "bản dịch tiếng Việt",
  "clauses": [
    { "type": "main", "text": "...", "role": "..." },
    { "type": "relative", "text": "...", "role": "..." }
  ],
  "simplified": "câu đơn giản hóa",
  "grammar_points": ["điểm 1", "điểm 2"]
}
`,o=await v(a,n,[{parts:[{text:e}]}]);return JSON.parse(o)}async function M(a,n,c){const e=c.replace(/^data:image\/\w+;base64,/,""),h=await v(a,n,[{parts:[{text:`
Đọc toàn bộ văn bản tiếng Anh trong ảnh cắt này.
1. Nhận diện chính xác 100% từng chữ và dấu câu.
2. Tách văn bản thành danh sách các câu hoàn chỉnh ("sentences").
3. Cung cấp bản dịch tiếng Việt sơ bộ cho từng câu.

Chỉ trả về JSON:
{
  "full_text": "toàn bộ đoạn văn",
  "sentences": [
    {
      "sentence": "câu tiếng Anh",
      "translation_vi": "bản dịch tiếng Việt"
    }
  ]
}
`},{inlineData:{mimeType:"image/png",data:e}}]}]);return JSON.parse(h)}export{j as a,L as f,T as l,M as o};
