function $(i){let n=i.trim();return n.startsWith("```json")?n=n.replace(/^```json\s*/i,"").replace(/\s*```$/,""):n.startsWith("```")&&(n=n.replace(/^```\s*/,"").replace(/\s*```$/,"")),n.trim()}async function C(i){const n=["v1beta","v1"],a=[];for(const e of n)try{const o=await fetch(`https://generativelanguage.googleapis.com/${e}/models?key=${i}`);if(!o.ok)continue;const h=await o.json();if(Array.isArray(h==null?void 0:h.models)){for(const s of h.models)if((s.supportedGenerationMethods||[]).includes("generateContent")){const g=(s.name||"").replace(/^models\//,"");a.some(u=>u.name===g)||a.push({name:g,displayName:s.displayName||g,apiVersion:e})}}}catch(o){console.warn(`[LexiLens] Failed querying ${e}/models:`,o)}return a}function S(i){if(!i||i.length===0)return null;const n=[/gemini-3\.0-flash/i,/gemini-3-flash/i,/gemini-2\.5-flash/i,/gemini-2\.0-flash/i,/gemini-1\.5-flash-latest/i,/gemini-1\.5-flash/i,/gemini-1\.5-flash-8b/i,/gemini-3\.0-pro/i,/gemini-2\.5-pro/i,/gemini-1\.5-pro/i,/flash/i,/gemini/i];for(const a of n){const e=i.find(o=>a.test(o.name));if(e)return e}return i[0]}async function f(i,n,a){var m,p,g,u,d,v,y,b,w,x,N;const e=[];n&&(e.push({name:n,apiVersion:"v1beta"}),e.push({name:n,apiVersion:"v1"}));const o=["gemini-3.0-flash","gemini-3-flash","gemini-2.5-flash","gemini-2.0-flash","gemini-1.5-flash-latest","gemini-1.5-flash","gemini-1.5-flash-8b","gemini-3.0-pro","gemini-2.5-pro","gemini-1.5-pro"];for(const c of o)e.some(t=>t.name===c&&t.apiVersion==="v1beta")||e.push({name:c,apiVersion:"v1beta"}),e.some(t=>t.name===c&&t.apiVersion==="v1")||e.push({name:c,apiVersion:"v1"});const h=async(c,t)=>{const r=`https://generativelanguage.googleapis.com/${t}/models/${c}:generateContent?key=${i}`;return fetch(r,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:a,generationConfig:{temperature:.2,responseMimeType:"application/json"}})})};let s="";for(const c of e)try{const t=await h(c.name,c.apiVersion);if(t.ok){const r=await t.json(),l=(d=(u=(g=(p=(m=r==null?void 0:r.candidates)==null?void 0:m[0])==null?void 0:p.content)==null?void 0:g.parts)==null?void 0:u[0])==null?void 0:d.text;if(l)return $(l)}else if(s=await t.text(),t.status===400&&s.includes("API_KEY_INVALID"))throw new Error("API Key Gemini không hợp lệ. Vui lòng kiểm tra lại trong phần Cài đặt.")}catch(t){if((v=t.message)!=null&&v.includes("API Key Gemini không hợp lệ"))throw t}try{console.info("[LexiLens] Discovering available models via ModelService.ListModels...");const c=await C(i),t=S(c);if(t){console.info(`[LexiLens] Selected discovered model: ${t.name} (${t.apiVersion})`);const r=await h(t.name,t.apiVersion);if(r.ok){const l=await r.json(),V=(N=(x=(w=(b=(y=l==null?void 0:l.candidates)==null?void 0:y[0])==null?void 0:b.content)==null?void 0:w.parts)==null?void 0:x[0])==null?void 0:N.text;if(V)return $(V)}else s=await r.text()}}catch(c){console.warn("[LexiLens] Dynamic model discovery failed:",c)}throw new Error(`Gemini API Error: Không thể gọi model khả dụng. Chi tiết: ${s}`)}async function A(i,n,a,e,o,h,s){const m=`
Bạn là trợ lý từ vựng học thuật cho sinh viên Việt Nam học chuyên ngành Ngôn ngữ Anh.
Lĩnh vực/Chủ đề: ${h||"auto"} ("auto" = tự đoán từ tiêu đề trang và câu văn).
Tiêu đề trang: ${o||"Bài báo"}
Câu chứa từ: "${e}"
Từ/cụm từ cần giải thích: "${a}"
${s?`Phiên âm IPA chuẩn từ điển: ${s}`:""}

Quy tắc bắt buộc:
1. "meaning_vi": Nghĩa tiếng Việt CHÍNH XÁC trong ngữ cảnh câu này (ưu tiên thuật ngữ chuyên ngành nếu có).
2. "why": Một câu tiếng Việt ngắn gọn chỉ ra manh mối ngữ cảnh (từ nào, cấu trúc nào xung quanh) quyết định nghĩa này.
3. "definition_en": Định nghĩa súc tích bằng tiếng Anh (simple English).
4. "other_meanings": Mảng tối đa 2-3 nghĩa phổ thông khác thường gặp.
5. "collocations": 2-3 cụm kết hợp từ phổ biến.
6. Chỉ trả về JSON tuân thủ đúng cấu trúc. Không thêm văn bản phụ.

JSON format:
{
  "headword": "từ gốc (lemma)",
  "pos": "verb | noun | adjective | adverb | idiom | phrase",
  "ipa": "${s||"/phiên âm/"}",
  "meaning_vi": "nghĩa trong ngữ cảnh",
  "definition_en": "english definition",
  "why": "Lý do vì sao nghĩa này...",
  "other_meanings": ["nghĩa 1", "nghĩa 2"],
  "collocations": ["collocation 1", "collocation 2"],
  "detected_topic": "lĩnh vực phát hiện được"
}
`,p=await f(i,n,[{parts:[{text:m}]}]);return{...JSON.parse(p),source:s?"dictionary+gemini":"gemini_fallback"}}async function _(i,n,a){const e=`
Phân tích ngữ pháp và cấu trúc câu tiếng Anh sau cho sinh viên chuyên ngành Ngôn ngữ Anh:
Câu: "${a}"

Yêu cầu học thuật:
1. Dịch câu sang tiếng Việt tự nhiên, chuẩn văn phong học thuật.
2. Tách câu thành các mệnh đề ("clauses"):
   - type: "main" (mệnh đề chính), "subordinate" (mệnh đề phụ trạng ngữ/danh từ), "relative" (mệnh đề quan hệ), "participial" (cụm phân từ/rút gọn).
   - text: đoạn văn bản gốc tương ứng.
   - role: vai trò ngữ pháp (ví dụ: "chủ ngữ chính và vị ngữ", "bổ nghĩa thời gian", "bổ ngữ cho danh từ X").
3. "simplified": Viết lại câu bằng cấu trúc đơn giản, dễ hiểu hơn.
4. "grammar_points": Tối đa 3 điểm ngữ pháp đáng chú ý (ví dụ: "Đảo ngữ", "Câu bị động kép", "Rút gọn mệnh đề quan hệ").

Chỉ trả về JSON thuần theo format:
{
  "translation_vi": "bản dịch tiếng Việt",
  "clauses": [
    { "type": "main", "text": "...", "role": "..." },
    { "type": "relative", "text": "...", "role": "..." }
  ],
  "simplified": "câu đơn giản hóa",
  "grammar_points": ["điểm 1", "điểm 2"]
}
`,o=await f(i,n,[{parts:[{text:e}]}]);return JSON.parse(o)}async function k(i,n,a){const e=a.replace(/^data:image\/\w+;base64,/,""),h=await f(i,n,[{parts:[{text:`
Đọc toàn bộ văn bản tiếng Anh trong ảnh cắt này.
1. Nhận diện chính xác 100% từng chữ và dấu câu.
2. Tách văn bản thành danh sách các câu hoàn chỉnh ("sentences").
3. Cung cấp bản dịch tiếng Việt sơ bộ cho từng câu.

Chỉ trả về JSON:
{
  "full_text": "toàn bộ đoạn văn",
  "sentences": [
    {
      "sentence": "câu tiếng Anh",
      "translation_vi": "bản dịch tiếng Việt"
    }
  ]
}
`},{inlineData:{mimeType:"image/png",data:e}}]}]);return JSON.parse(h)}export{_ as a,C as f,A as l,k as o};
