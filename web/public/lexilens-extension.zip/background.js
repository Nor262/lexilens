import{i as L,r as E,c as k}from"./assets/fsrs-CNjhJkfz.js";async function N(e){var n,a;try{const i=e.trim().toLowerCase().replace(/[^a-zA-Z-]/g,"");if(!i||i.includes(" "))return null;const t=await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(i)}`);if(!t.ok)return null;const r=await t.json();if(!r||r.length===0)return null;const c=r[0];let o=c.phonetic,h;if(c.phonetics&&c.phonetics.length>0){for(const l of c.phonetics)if(!o&&l.text&&(o=l.text),l.audio&&l.audio.trim().length>0&&(h=l.audio,l.audio.includes("-us.mp3")||l.audio.includes("-uk.mp3")))break}const u=(n=c.meanings)==null?void 0:n[0],s=u==null?void 0:u.partOfSpeech,d=(a=u==null?void 0:u.definitions)==null?void 0:a.map(l=>l.definition).slice(0,3);return{ipa:o,audioUrl:h,pos:s,definitions:d}}catch(i){return console.warn("[LexiLens] Free Dictionary API error (fallback triggered):",i),null}}const b="gemini-2.0-flash",v="https://generativelanguage.googleapis.com/v1beta/models";function T(e){let n=e.trim();return n.startsWith("```json")?n=n.replace(/^```json\s*/i,"").replace(/\s*```$/,""):n.startsWith("```")&&(n=n.replace(/^```\s*/,"").replace(/\s*```$/,"")),n.trim()}async function S(e,n,a){var h,u,s,d,l;const t=`${v}/${n||b}:generateContent?key=${e}`,r=await fetch(t,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:a,generationConfig:{temperature:.2,responseMimeType:"application/json"}})});if(!r.ok){const m=await r.text();throw new Error(`Gemini API Error (${r.status}): ${m}`)}const c=await r.json(),o=(l=(d=(s=(u=(h=c==null?void 0:c.candidates)==null?void 0:h[0])==null?void 0:u.content)==null?void 0:s.parts)==null?void 0:d[0])==null?void 0:l.text;if(!o)throw new Error("Gemini returned an empty response.");return T(o)}async function $(e,n,a,i,t,r,c){const o=`
Bạn là trợ lý từ vựng học thuật cho sinh viên Việt Nam học chuyên ngành Ngôn ngữ Anh.
Lĩnh vực/Chủ đề: ${r||"auto"} ("auto" = tự đoán từ tiêu đề trang và câu văn).
Tiêu đề trang: ${t||"Bài báo"}
Câu chứa từ: "${i}"
Từ/cụm từ cần giải thích: "${a}"
${c?`Phiên âm IPA chuẩn từ điển: ${c}`:""}

Quy tắc bắt buộc:
1. "meaning_vi": Nghĩa tiếng Việt CHÍNH XÁC trong ngữ cảnh câu này (ưu tiên thuật ngữ chuyên ngành nếu có).
2. "why": Một câu tiếng Việt ngắn gọn chỉ ra manh mối ngữ cảnh (từ nào, cấu trúc nào xung quanh) quyết định nghĩa này.
3. "definition_en": Định nghĩa súc tích bằng tiếng Anh (simple English).
4. "other_meanings": Mảng tối đa 2-3 nghĩa phổ thông khác thường gặp.
5. "collocations": 2-3 cụm kết hợp từ phổ biến.
6. Chỉ trả về JSON tuân thủ đúng cấu trúc. Không thêm văn bản phụ.

JSON format:
{
  "headword": "từ gốc (lemma)",
  "pos": "verb | noun | adjective | adverb | idiom | phrase",
  "ipa": "${c||"/phiên âm/"}",
  "meaning_vi": "nghĩa trong ngữ cảnh",
  "definition_en": "english definition",
  "why": "Lý do vì sao nghĩa này...",
  "other_meanings": ["nghĩa 1", "nghĩa 2"],
  "collocations": ["collocation 1", "collocation 2"],
  "detected_topic": "lĩnh vực phát hiện được"
}
`,h=await S(e,n,[{parts:[{text:o}]}]);return{...JSON.parse(h),source:c?"dictionary+gemini":"gemini_fallback"}}async function P(e,n,a){const i=`
Phân tích ngữ pháp và cấu trúc câu tiếng Anh sau cho sinh viên chuyên ngành Ngôn ngữ Anh:
Câu: "${a}"

Yêu cầu học thuật:
1. Dịch câu sang tiếng Việt tự nhiên, chuẩn văn phong học thuật.
2. Tách câu thành các mệnh đề ("clauses"):
   - type: "main" (mệnh đề chính), "subordinate" (mệnh đề phụ trạng ngữ/danh từ), "relative" (mệnh đề quan hệ), "participial" (cụm phân từ/rút gọn).
   - text: đoạn văn bản gốc tương ứng.
   - role: vai trò ngữ pháp (ví dụ: "chủ ngữ chính và vị ngữ", "bổ nghĩa thời gian", "bổ ngữ cho danh từ X").
3. "simplified": Viết lại câu bằng cấu trúc đơn giản, dễ hiểu hơn.
4. "grammar_points": Tối đa 3 điểm ngữ pháp đáng chú ý (ví dụ: "Đảo ngữ", "Câu bị động kép", "Rút gọn mệnh đề quan hệ").

Chỉ trả về JSON thuần theo format:
{
  "translation_vi": "bản dịch tiếng Việt",
  "clauses": [
    { "type": "main", "text": "...", "role": "..." },
    { "type": "relative", "text": "...", "role": "..." }
  ],
  "simplified": "câu đơn giản hóa",
  "grammar_points": ["điểm 1", "điểm 2"]
}
`,t=await S(e,n,[{parts:[{text:i}]}]);return JSON.parse(t)}async function O(e,n,a){var s,d,l,m,f;const i=a.replace(/^data:image\/\w+;base64,/,""),t=`
Đọc toàn bộ văn bản tiếng Anh trong ảnh cắt này.
1. Nhận diện chính xác 100% từng chữ và dấu câu.
2. Tách văn bản thành danh sách các câu hoàn chỉnh ("sentences").
3. Cung cấp bản dịch tiếng Việt sơ bộ cho từng câu.

Chỉ trả về JSON:
{
  "full_text": "toàn bộ đoạn văn",
  "sentences": [
    {
      "sentence": "câu tiếng Anh",
      "translation_vi": "bản dịch tiếng Việt"
    }
  ]
}
`,c=`${v}/${n||b}:generateContent?key=${e}`,o=await fetch(c,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:t},{inlineData:{mimeType:"image/png",data:i}}]}],generationConfig:{temperature:.1,responseMimeType:"application/json"}})});if(!o.ok){const x=await o.text();throw new Error(`Gemini OCR Error (${o.status}): ${x}`)}const h=await o.json(),u=(f=(m=(l=(d=(s=h==null?void 0:h.candidates)==null?void 0:s[0])==null?void 0:d.content)==null?void 0:l.parts)==null?void 0:m[0])==null?void 0:f.text;return JSON.parse(T(u))}const y={geminiApiKey:"",preferredModel:"gemini-2.0-flash",defaultTopic:"auto",dailyReminderHour:20,customTopics:["CNTT & AI","Kinh tế & Tài chính","Học thuật & NCKH","Văn hóa & Xã hội"]};function w(e,n,a,i){const t=`${e}:${n.trim().toLowerCase()}|${a.trim().toLowerCase()}|${i.trim().toLowerCase()}`;let r=0;for(let c=0;c<t.length;c++){const o=t.charCodeAt(c);r=(r<<5)-r+o,r|=0}return`cache_${Math.abs(r).toString(36)}`}async function A(){return new Promise(e=>{if(typeof chrome>"u"||!chrome.storage){e(y);return}chrome.storage.local.get(["settings"],n=>{e({...y,...n.settings||{}})})})}async function D(e){const a={...await A(),...e};return new Promise(i=>{chrome.storage.local.set({settings:a},()=>{i(a)})})}async function g(){return new Promise(e=>{if(typeof chrome>"u"||!chrome.storage){e([]);return}chrome.storage.local.get(["flashcards"],n=>{e(n.flashcards||[])})})}async function K(e){const n=await g();if(n.some(t=>t.headword.toLowerCase()===e.headword.toLowerCase()&&t.meaning_vi===e.meaning_vi))return{success:!0,isDuplicate:!0};const i=[e,...n];return await new Promise(t=>{chrome.storage.local.set({flashcards:i},()=>{t()})}),await p(),{success:!0,isDuplicate:!1}}async function G(e){const n=await g(),a=n.findIndex(i=>i.id===e.id);a!==-1&&(n[a]=e,await new Promise(i=>{chrome.storage.local.set({flashcards:n},()=>{i()})}),await p())}async function p(){if(typeof chrome>"u"||!chrome.action)return;const n=(await g()).filter(L).length;n>0?(chrome.action.setBadgeText({text:n.toString()}),chrome.action.setBadgeBackgroundColor({color:"#9a4023"})):chrome.action.setBadgeText({text:""})}async function C(e){return new Promise(n=>{if(typeof chrome>"u"||!chrome.storage){n(null);return}chrome.storage.local.get([e],a=>{n(a[e]||null)})})}async function _(e,n){typeof chrome>"u"||!chrome.storage||chrome.storage.local.set({[e]:n})}console.log("[LexiLens] Background Service Worker initialized.");chrome.alarms.create("refresh_badge",{periodInMinutes:30});chrome.alarms.onAlarm.addListener(e=>{e.name==="refresh_badge"&&p()});p();chrome.commands.onCommand.addListener(async e=>{if(e==="capture_screen"){const[n]=await chrome.tabs.query({active:!0,currentWindow:!0});n!=null&&n.id&&chrome.tabs.sendMessage(n.id,{type:"TRIGGER_SCREEN_CROP"})}});chrome.runtime.onMessage.addListener((e,n,a)=>((async()=>{try{const i=await A();switch(e.type){case"GET_SETTINGS":{a({success:!0,data:i});break}case"SAVE_SETTINGS":{const t=await D(e.payload);a({success:!0,data:t});break}case"LOOKUP_WORD":{const{selection:t,sentence:r,pageTitle:c,topic:o}=e.payload,h=w("word",t,r,o),u=await C(h);if(u){console.log("[LexiLens] Returning cached word result:",t),a({success:!0,data:u});return}if(!i.geminiApiKey){a({success:!1,error:"Chưa cấu hình Gemini API Key. Vui lòng bấm vào icon LexiLens hoặc mở Cài đặt để nhập Key miễn phí."});return}let s=null;try{s=await N(t)}catch(l){console.warn("[LexiLens] Dictionary lookup failed, falling back to pure Gemini:",l)}const d=await $(i.geminiApiKey,i.preferredModel,t,r,c,o,s==null?void 0:s.ipa);s!=null&&s.audioUrl&&(d.audio_url=s.audioUrl),await _(h,d),a({success:!0,data:d});break}case"ANALYZE_SENTENCE":{const{sentence:t}=e.payload,r=w("sentence",t,"",""),c=await C(r);if(c){a({success:!0,data:c});return}if(!i.geminiApiKey){a({success:!1,error:"Chưa cấu hình Gemini API Key. Vui lòng mở Cài đặt LexiLens để nhập Key."});return}const o=await P(i.geminiApiKey,i.preferredModel,t);await _(r,o),a({success:!0,data:o});break}case"CAPTURE_VISIBLE_TAB":{const t=await chrome.tabs.captureVisibleTab({format:"png"});a({success:!0,data:t});break}case"PERFORM_OCR":{const{imageBase64:t}=e.payload;if(!i.geminiApiKey){a({success:!1,error:"Chưa cấu hình Gemini API Key để nhận diện ảnh (OCR)."});return}const r=await O(i.geminiApiKey,i.preferredModel,t);a({success:!0,data:r});break}case"SAVE_FLASHCARD":{const t=e.payload,r={id:`card_${Date.now()}_${Math.random().toString(36).substring(2,7)}`,headword:t.headword,pos:t.pos||"word",ipa:t.ipa||"",meaning_vi:t.meaning_vi,definition_en:t.definition_en||"",why:t.why||"",sentence:t.sentence,article_title:t.article_title||"Tài liệu",article_url:t.article_url||"",topic:t.topic||"Chung",image_crop:t.image_crop,audio_url:t.audio_url,created_at:Date.now(),fsrs:k()},c=await K(r);a({success:!0,data:c});break}case"GET_CARDS":{const t=await g();a({success:!0,data:t});break}case"UPDATE_CARD_FSRS":{const{cardId:t,rating:r}=e.payload,o=(await g()).find(s=>s.id===t);if(!o){a({success:!1,error:"Không tìm thấy thẻ"});return}const{updatedCard:h,scheduledDays:u}=E(o,r);await G(h),a({success:!0,data:{updatedCard:h,scheduledDays:u}});break}default:a({success:!1,error:"Unknown message type"})}}catch(i){console.error("[LexiLens] Background Error:",i),a({success:!1,error:i.message||"Lỗi xử lý nền"})}})(),!0));
